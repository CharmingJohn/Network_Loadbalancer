#!/bin/sh

mkdir -p build-aux

aclocal --install
autoheader
automake --add-missing
autoreconf
